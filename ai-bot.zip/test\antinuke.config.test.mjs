import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import test from "node:test";
import { promisify } from "node:util";
const execFileP = promisify(execFile);
const CLI = "dist/cli.js";

test("antinuke policy roundtrip", async () => {
  const set = await execFileP(process.execPath, [
    CLI,
    "antinuke:set",
    JSON.stringify({ enabled: true, windowMs: 5000 }),
  ]);
  assert.match(set.stdout, /"ok":\s*true/);

  const st = await execFileP(process.execPath, [CLI, "antinuke:status"]);
  assert.match(st.stdout, /"enabled":\s*true/);
});
