// scripts/repo-inventory.cjs
/* Inventory your repo: lists files (size, mtime), key configs, structure.
   Outputs:
     .handoff/inventory.json  (full machine-readable)
     .handoff/inventory.txt   (human summary)
*/
const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const crypto = require("crypto");

const ROOT = process.cwd();
const OUT_DIR = path.join(ROOT, ".handoff");
const OUT_JSON = path.join(OUT_DIR, "inventory.json");
const OUT_TXT = path.join(OUT_DIR, "inventory.txt");

const IGNORE_DIRS = new Set([
  "node_modules",
  ".git",
  ".idea",
  ".vscode",
  ".DS_Store",
  "dist",
  "coverage",
  ".next",
  "out",
  "build",
  ".cache",
]);

const MAX_SAMPLE = 4096; // first 4KB for quick peek
const HASH_SAMPLE = 65536; // up to 64KB for quick hash

function isBinaryExt(p) {
  return /\.(png|jpg|jpeg|gif|webp|ico|pdf|zip|gz|7z|rar|exe|dll|pdb|woff2?|ttf)$/i.test(
    p,
  );
}

async function walk(dir) {
  const rel = path.relative(ROOT, dir).replace(/\\/g, "/");
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  const result = [];
  for (const e of entries) {
    const full = path.join(dir, e.name);
    const relPath = path.relative(ROOT, full).replace(/\\/g, "/");
    const top = relPath.split("/")[0];
    if (IGNORE_DIRS.has(e.name) || IGNORE_DIRS.has(top)) continue;
    try {
      const st = await fsp.stat(full);
      if (e.isDirectory()) {
        result.push({ type: "dir", path: relPath });
        const child = await walk(full);
        result.push(...child);
      } else if (e.isFile()) {
        let sample = "";
        let hash = "";
        if (!isBinaryExt(e.name)) {
          try {
            const fd = await fsp.open(full, "r");
            const buf = Buffer.alloc(Math.min(MAX_SAMPLE, st.size));
            await fd.read(buf, 0, buf.length, 0);
            await fd.close();
            sample = buf.toString("utf8");
          } catch {}
        }
        try {
          const fd = await fsp.open(full, "r");
          const len = Math.min(HASH_SAMPLE, st.size);
          const buf = Buffer.alloc(len);
          await fd.read(buf, 0, buf.length, 0);
          await fd.close();
          hash = crypto.createHash("sha1").update(buf).digest("hex");
        } catch {}
        result.push({
          type: "file",
          path: relPath,
          size: st.size,
          mtime: st.mtime.toISOString(),
          hash,
          peek: sample.slice(0, 400), // trim for readability
        });
      }
    } catch {}
  }
  return result;
}

function pick(obj, keys) {
  const o = {};
  for (const k of keys)
    if (obj && Object.prototype.hasOwnProperty.call(obj, k)) o[k] = obj[k];
  return o;
}

async function main() {
  await fsp.mkdir(OUT_DIR, { recursive: true });

  // package.json
  let pkg = null;
  try {
    pkg = JSON.parse(
      await fsp.readFile(path.join(ROOT, "package.json"), "utf8"),
    );
  } catch {}
  const pkgSlim = pkg
    ? {
        name: pkg.name,
        version: pkg.version,
        type: pkg.type,
        main: pkg.main,
        module: pkg.module,
        exports: pkg.exports,
        scripts: pkg.scripts,
        dependencies: pkg.dependencies,
        devDependencies: pkg.devDependencies,
      }
    : null;

  // tsconfig.json (optional)
  let tsconfig = null;
  try {
    tsconfig = JSON.parse(
      await fsp.readFile(path.join(ROOT, "tsconfig.json"), "utf8"),
    );
  } catch {}

  // env flags
  const envExists = fs.existsSync(path.join(ROOT, ".env"));
  const envExampleExists = fs.existsSync(path.join(ROOT, ".env.example"));

  // src presence
  const srcExists = fs.existsSync(path.join(ROOT, "src"));

  // walk
  const tree = await walk(ROOT);

  // categorize by top-level dir
  const byTop = {};
  for (const item of tree) {
    const top = item.path.split("/")[0] || ".";
    if (!byTop[top]) byTop[top] = [];
    byTop[top].push(item);
  }

  // quick booleans
  const has = {
    src: srcExists,
    modules: fs.existsSync(path.join(ROOT, "src", "modules")),
    utils: fs.existsSync(path.join(ROOT, "src", "utils")),
    data: fs.existsSync(path.join(ROOT, "src", "data")),
  };

  // summarize key files if present
  function sampleFile(p) {
    try {
      const full = path.join(ROOT, p);
      if (!fs.existsSync(full)) return null;
      const content = fs.readFileSync(full, "utf8");
      return content.slice(0, 800);
    } catch {
      return null;
    }
  }

  const featureFlags = sampleFile("src/data/feature-flags.json");
  const domainLists = sampleFile("src/data/reputation/domain-lists.json");

  const inventory = {
    when: new Date().toISOString(),
    system: {
      node: process.version,
      platform: process.platform,
      arch: process.arch,
    },
    has,
    env: { envExists, envExampleExists },
    packageJson: pkgSlim,
    tsconfig,
    paths: {
      root: ROOT.replace(/\\/g, "/"),
    },
    counts: {
      files: tree.filter((x) => x.type === "file").length,
      dirs: tree.filter((x) => x.type === "dir").length,
    },
    tree,
    byTopSummary: Object.fromEntries(
      Object.entries(byTop).map(([k, v]) => [
        k,
        {
          files: v.filter((i) => i.type === "file").length,
          dirs: v.filter((i) => i.type === "dir").length,
        },
      ]),
    ),
    samples: { featureFlags, domainLists },
  };

  fs.writeFileSync(OUT_JSON, JSON.stringify(inventory, null, 2), "utf8");

  // Pretty text summary
  const lines = [];
  lines.push(`[inventory] ${inventory.when}`);
  lines.push(`node: ${inventory.system.node}  cwd: ${inventory.paths.root}`);
  lines.push(`top-level summary:`);
  for (const [k, v] of Object.entries(inventory.byTopSummary)) {
    lines.push(
      `  ${k.padEnd(16)} files:${String(v.files).padStart(5)}  dirs:${String(v.dirs).padStart(4)}`,
    );
  }
  const scripts = pkgSlim?.scripts ? Object.keys(pkgSlim.scripts) : [];
  lines.push(`scripts: ${scripts.join(", ") || "(none)"}`);
  lines.push(
    `src modules/utils/data present: ${Object.values(has).every(Boolean) ? "YES" : JSON.stringify(has)}`,
  );
  if (featureFlags)
    lines.push(
      `feature-flags.json peek: ${featureFlags.slice(0, 160).replace(/\s+/g, " ")}`,
    );
  fs.writeFileSync(OUT_TXT, lines.join("\n"), "utf8");

  console.log(`inventory written:\n  ${OUT_JSON}\n  ${OUT_TXT}`);
}

main().catch((err) => {
  console.error("inventory failed:", err);
  process.exit(1);
});
